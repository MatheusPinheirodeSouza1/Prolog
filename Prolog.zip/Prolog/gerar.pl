gerar(A,B,L):- A =:= B -> L = [A].
gerar(A,B,L):- A1 is A+1, gerar(A1,B,L1), L = [A | L1 ] .

