medio([],0).
medio(L,M):-nelementos(L,M1), soma(L,S), M is (S/M1).

nelementos([],0).
nelementos([_ | L],S):-nelementos(L,S1),S is S1+1.

soma([],0).
soma([X | L],M):- soma(L,M1), M is X+M1.
