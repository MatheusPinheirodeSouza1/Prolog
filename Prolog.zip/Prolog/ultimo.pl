ultimo([X | L],S):- busca(X,L,S1),S is S1.

busca(A,[],S):- S is A.
busca(_,[X | L],S):- busca(X,L,S1), S is S1.
