maior([],0).
maior([X | L],M):- maior(L,M1), X < M1 -> M is M1 ; M is X.
