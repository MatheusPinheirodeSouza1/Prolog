inserirfim(A,[],S):- S = [A|[]].
inserirfim(A,[X|L],S):- inserirfim(A,L,S1),S = [X|S1].
