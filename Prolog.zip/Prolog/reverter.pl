reverter([X|L],R):- acao(X,L,R1), R = R1.


acao(_,[],R):- R = [].
acao(A,[X|L],R):-R1 = [A|R], acao(X,L,R1),R = [R|R1].

