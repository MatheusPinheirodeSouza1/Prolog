adjacente(A,B,[X|L]):- A =:= X -> proximo(A,B,L);adjacente(A,B,L).

proximo(A,B,[X|L]):- B =:= X ;adjacente(A,B,[X|L]).
